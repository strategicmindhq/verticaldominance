document.addEventListener('DOMContentLoaded', function () {

  // ===========================
  // PARTICLE SYSTEM
  // ===========================
  const canvas = document.getElementById('particle-canvas');
  if (canvas) {
    const ctx = canvas.getContext('2d');
    let W, H;
    function resizeCanvas() { W = canvas.width = window.innerWidth; H = canvas.height = window.innerHeight; }
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas, { passive: true });

    class Particle {
      constructor() { this.reset(true); }
      reset(init) {
        this.x = Math.random() * W;
        this.y = init ? Math.random() * H : H + 10;
        this.size = Math.random() * 1.5 + 0.3;
        this.speedY = -(Math.random() * 0.35 + 0.12);
        this.speedX = (Math.random() - 0.5) * 0.12;
        this.alpha = Math.random() * 0.5 + 0.08;
        this.fadeSpeed = Math.random() * 0.003 + 0.001;
        this.fadeDir = -1;
        this.gold = Math.random() > 0.5;
      }
      update() {
        this.y += this.speedY; this.x += this.speedX;
        this.alpha += this.fadeSpeed * this.fadeDir;
        if (this.alpha <= 0.05 || this.alpha >= 0.6) this.fadeDir *= -1;
        if (this.y < -10) this.reset(false);
      }
      draw() {
        ctx.save(); ctx.globalAlpha = Math.max(0, this.alpha);
        if (this.gold) {
          ctx.fillStyle = '#c9a227';
          ctx.fillRect(this.x - this.size, this.y, this.size * 2, 0.5);
          ctx.fillRect(this.x, this.y - this.size, 0.5, this.size * 2);
        } else {
          ctx.fillStyle = '#fff'; ctx.beginPath();
          ctx.arc(this.x, this.y, this.size * 0.5, 0, Math.PI * 2); ctx.fill();
        }
        ctx.restore();
      }
    }

    const particles = [];
    for (let i = 0; i < 100; i++) particles.push(new Particle());
    function animateParticles() { ctx.clearRect(0, 0, W, H); particles.forEach(p => { p.update(); p.draw(); }); requestAnimationFrame(animateParticles); }
    animateParticles();
  }

  // ===========================
  // TIMER SWEEP ANIMATION
  // ===========================
  const sweep = document.getElementById('timer-sweep');
  if (sweep) {
    let sweepPos = -80;
    function animateSweep() {
      sweepPos += 0.6;
      if (sweepPos > 130) sweepPos = -80;
      sweep.style.left = sweepPos + '%';
      requestAnimationFrame(animateSweep);
    }
    animateSweep();
  }

  // ===========================
  // COLON BLINK
  // ===========================
  const colon1 = document.getElementById('colon1');
  if (colon1) {
    setInterval(() => {
      colon1.style.opacity = colon1.style.opacity === '0.15' ? '1' : '0.15';
    }, 500);
  }

  // ===========================
  // COUNTDOWN TIMER — 10 min + ms via rAF
  // ===========================
  const timerBar = document.getElementById('timer-bar');
  const timerLabel = document.getElementById('timer-label');
  const elMin = document.getElementById('t-min');
  const elSec = document.getElementById('t-sec');
  const elMs  = document.getElementById('t-ms');

  if (elMin && elSec && elMs) {
    const DURATION_MS = 10 * 60 * 1000;
    const KEY = 'jh_end_v3';
    let endTime;
    try {
      const stored = sessionStorage.getItem(KEY);
      endTime = stored && parseInt(stored) > Date.now() ? parseInt(stored) : Date.now() + DURATION_MS;
      sessionStorage.setItem(KEY, endTime);
    } catch(e) {
      endTime = Date.now() + DURATION_MS;
    }

    function pad2(n) { return String(Math.floor(n)).padStart(2, '0'); }
    let lastMin = '', lastSec = '', expired = false;

    function tickBounce(el) {
      el.style.transform = 'scale(1.2) translateY(-2px)';
      setTimeout(() => { el.style.transform = ''; }, 150);
    }

    function runTimer() {
      if (expired) return;
      const remaining = Math.max(0, endTime - Date.now());
      const totalSec = remaining / 1000;
      const mins = Math.floor(totalSec / 60);
      const secs = Math.floor(totalSec % 60);
      const ms   = Math.floor((remaining % 1000) / 10);

      const mStr = pad2(mins), sStr = pad2(secs), msStr = pad2(ms);

      if (mStr !== lastMin) { elMin.textContent = mStr; tickBounce(elMin); lastMin = mStr; }
      if (sStr !== lastSec) { elSec.textContent = sStr; tickBounce(elSec); lastSec = sStr; }
      elMs.textContent = msStr;

      if (remaining <= 120000 && remaining > 0 && timerBar) {
        timerBar.style.background = '#150000';
        timerBar.style.borderBottomColor = 'rgba(220,50,30,0.9)';
        elMin.style.color = '#ff5533';
        elSec.style.color = '#ff5533';
        if (timerLabel) timerLabel.style.color = '#ff7766';
      }

      if (remaining <= 0) {
        expired = true;
        elMin.textContent = '00'; elSec.textContent = '00'; elMs.textContent = '00';
        if (timerLabel) timerLabel.textContent = '⚠ THIS PRICE MAY BE GONE';
        return;
      }
      requestAnimationFrame(runTimer);
    }
    requestAnimationFrame(runTimer);
  }

  // ===========================
  // NAV SCROLL STATE
  // ===========================
  const nav = document.getElementById('nav');
  if (nav) {
    window.addEventListener('scroll', function () {
      if (window.scrollY > 80) {
        nav.style.background = 'rgba(8,8,8,0.99)';
        nav.style.boxShadow = '0 2px 20px rgba(201,162,39,0.1)';
      } else {
        nav.style.background = 'rgba(8,8,8,0.9)';
        nav.style.boxShadow = 'none';
      }
    }, { passive: true });
  }

  // ===========================
  // SCROLL REVEAL
  // ===========================
  const revealEls = document.querySelectorAll('.reveal-up');
  if (revealEls.length) {
    const ro = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (entry.isIntersecting) {
          const delay = parseFloat(entry.target.dataset.delay || 0) * 1000;
          setTimeout(() => entry.target.classList.add('is-visible'), delay);
          ro.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -20px 0px' });
    revealEls.forEach(el => ro.observe(el));
  }

  // ===========================
  // CARD STAGGER REVEAL
  // ===========================
  const cardEls = document.querySelectorAll('.inside-card, .science-block, .who-item, .bonus-feat');
  if (cardEls.length) {
    const co = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0) scale(1)';
          co.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -30px 0px' });
    cardEls.forEach(function(el, i) {
      el.style.opacity = '0';
      el.style.transform = 'translateY(18px) scale(0.98)';
      el.style.transition = `opacity 0.55s ease ${i * 0.035}s, transform 0.55s cubic-bezier(0.34,1.56,0.64,1) ${i * 0.035}s`;
      co.observe(el);
    });
  }

  // ===========================
  // STICKY CTA TOGGLE
  // ===========================
  const stickyCta = document.getElementById('sticky-cta');
  const heroBtn = document.querySelector('.btn-pulse');
  if (stickyCta && heroBtn) {
    stickyCta.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
    new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        stickyCta.style.opacity = entry.isIntersecting ? '0' : '1';
        stickyCta.style.transform = entry.isIntersecting ? 'translateY(100%)' : 'translateY(0)';
        stickyCta.style.pointerEvents = entry.isIntersecting ? 'none' : 'auto';
      });
    }, { threshold: 0.3 }).observe(heroBtn);
  }

  // ===========================
  // BOOK FLOAT + MOUSE TILT
  // ===========================
  const bookMock = document.querySelector('.book-mock');
  if (bookMock) {
    let tick = 0, tRX = 0, tRY = 0, cRX = 0, cRY = 0;
    if (!('ontouchstart' in window)) {
      document.addEventListener('mousemove', function(e) {
        tRX = ((e.clientY - window.innerHeight/2) / (window.innerHeight/2)) * -5;
        tRY = ((e.clientX - window.innerWidth/2)  / (window.innerWidth/2))  *  8;
      });
    }
    function floatBook() {
      tick += 0.012;
      cRX += (tRX - cRX) * 0.06; cRY += (tRY - cRY) * 0.06;
      bookMock.style.transform = `translateY(${Math.sin(tick)*7}px) rotateZ(${Math.sin(tick*0.7)*0.6}deg) perspective(800px) rotateX(${cRX}deg) rotateY(${cRY}deg)`;
      requestAnimationFrame(floatBook);
    }
    floatBook();
  }

  // ===========================
  // HERO GLOW PARALLAX
  // ===========================
  const heroGlows = document.querySelectorAll('.hero-glow');
  if (heroGlows.length) {
    window.addEventListener('scroll', function() {
      const s = window.scrollY;
      heroGlows.forEach((g, i) => { g.style.transform = `translateY(${s * (i===0?0.3:0.5)}px)`; });
    }, { passive: true });
  }

  // ===========================
  // SMOOTH SCROLL
  // ===========================
  document.querySelectorAll('a[href^="#"]').forEach(function(a) {
    a.addEventListener('click', function(e) {
      const t = document.querySelector(this.getAttribute('href'));
      if (t) { e.preventDefault(); t.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    });
  });

});
